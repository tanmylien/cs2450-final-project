import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class Coder implements ActionListener {
	JTextField jtfplaintext;
	JTextField jtfciphertext;
	
	Coder (){
		
		//Create a new JFrame container
		JFrame jfrm = new JFrame("A Simple Code Machine");
		
		//Specify FlowLayout for the layout manager
		jfrm.getContentPane().setLayout(new FlowLayout());
		
		//Give the frame an initial size
		jfrm.setSize(340,220);
		
		//Terminate the program when the user closes the application
		jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Create two labels
		JLabel jlabplaintext = new JLabel (" Plain Text: ");
		JLabel jlabciphertext = new JLabel (" Cipher Text: ");
		
		//Create two text field instances
		jtfplaintext = new JTextField(20);
		jtfciphertext = new JTextField(20);
		
		//Set the action commands for the text fields
		jtfplaintext.setActionCommand("Encode");
		jtfciphertext.setActionCommand("Decode");
		
		//Add action listeners for the text fields
		jtfplaintext.addActionListener(this);
		jtfciphertext.addActionListener(this);
		
		//Add the text fields and labels to the content pane.
		jfrm.getContentPane().add(jlabplaintext);
		jfrm.getContentPane().add(jtfplaintext);
		jfrm.getContentPane().add(jlabciphertext);
		jfrm.getContentPane().add(jtfciphertext);
		
		//Create push button instances
		JButton jbtnEncode = new JButton("Encode");
		JButton jbtnDecode = new JButton("Decode");
		JButton jbtnReset = new JButton("Reset");
		
		//Add action listeners for the buttons
		jbtnEncode.addActionListener(this);
		jbtnDecode.addActionListener(this);
		jbtnReset.addActionListener(this);
		
		//Add the buttons to the content pane
		jfrm.getContentPane().add(jbtnEncode);
		jfrm.getContentPane().add(jbtnDecode);
		jfrm.getContentPane().add(jbtnReset);
		
		//Display the frame
		jfrm.setVisible(true);
	}
	
	//Handle action events
	public void actionPerformed(ActionEvent ae) {
		
		//If action command is "Encode" then encode the string
		if (ae.getActionCommand().equals("Encode")) {
			
			//Obtain the plain text and put it into a StringBuilder
			StringBuilder str = new StringBuilder(jtfplaintext.getText());
			
			//Add 1 to each character
			for (int i=0; i<str.length(); i++) {
				str.setCharAt(i, (char) (str.charAt(i) + 1 ));
			}
			
			//Set the coded text into the Cipher Text field
			jtfciphertext.setText(str.toString());
		}
		else if (ae.getActionCommand().equals("Decode")) {
			StringBuilder str = new StringBuilder(jtfciphertext.getText());
			
			for (int i=0; i<str.length(); i++) {
				str.setCharAt(i, (char) (str.charAt(i)-1));
			}
			//Set the decoded text into the Plain Text field
			jtfplaintext.setText(str.toString());
		}
		else {
			jtfplaintext.setText(" ");
			jtfciphertext.setText(" ");
		}
	}
	public static void main (String args[]) {
		
		//Create the frame on the event dispatching thread
		SwingUtilities.invokeLater(new Runnable(){
			public void run() {
				new Coder();
			}
		});
	}
}
