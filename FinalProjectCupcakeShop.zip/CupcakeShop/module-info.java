/**
 * 
 */
/**
 * 
 */
module APP_BanHang {
	requires java.desktop;
}